1. Download latest Doxygen ZIP file from http://www.stack.nl/~dimitri/doxygen/download.html

2. Uncompress the following files in the BIN subdirectory:

    doxygen.exe
    doxyindexer.exe
    doxysearch.cgi
